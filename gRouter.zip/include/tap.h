/*
 * tap.h (header file the Tap driver)
 * AUTHOR: Muthucumaru Maheswaran
 *
 * VERSION:
 */



/*
 * function prototypes
 */

void *toTapDev(void *arg);
void* fromTapDev(void *arg);
